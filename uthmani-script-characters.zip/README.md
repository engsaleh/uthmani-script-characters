# رموز المصحف العثماني - Uthmani Script Characters

An interactive web application to display and explore the characters and symbols used in the Uthmani script of the Holy Quran. This tool is designed for students, researchers, and anyone interested in the intricacies of the Quranic text.

## ✨ Features

- **Comprehensive Character Set**: Displays a complete set of characters, diacritics, and symbols from the Uthmani script, based on the provided reference chart.
- **Interactive Tooltips**: Hover over any character to view its name and a detailed Arabic description of its tajweed rule or function.
- **Authentic Typography**: Utilizes the beautiful **Amiri** font, which is specifically designed for classical Arabic and Quranic script, ensuring accurate and elegant rendering.
- **Elegant & Responsive Design**: A clean, aesthetically pleasing interface inspired by Islamic art, which is fully responsive and accessible on desktops, tablets, and mobile devices.
- **Educational**: Serves as a quick reference and learning tool for understanding the specific meanings of various Quranic symbols.

## 💻 Technologies Used

- **React**: A modern JavaScript library for building user interfaces.
- **TypeScript**: For static typing, improving code quality and maintainability.
- **Tailwind CSS**: A utility-first CSS framework for rapid and custom UI development.
- **Google Fonts**: For importing the specialized Amiri font.

## 🚀 How to Run Locally

This project is a static web application and does not require a complex build process. You can run it easily with a local web server.

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/your-username/uthmani-script-characters.git
    cd uthmani-script-characters
    ```

2.  **Serve the project:**
    If you have a local server extension in your code editor (like Live Server for VS Code), you can simply open `index.html` with it.

    Alternatively, you can use a simple command-line server. If you have Node.js installed, you can use `serve`:
    ```bash
    # Install serve globally if you don't have it
    npm install -g serve

    # Run the server in the project directory
    serve .
    ```
    The application will now be running on a local port (e.g., `http://localhost:3000`).

## 🙏 Acknowledgements

- This project was inspired by the character map at [karachvi.com](https://karachvi.com/quran/charsUsedUthmani.html).
- The beautiful Arabic typography is made possible by the [Amiri Font](https://fonts.google.com/specimen/Amiri) project.

---

<div dir="rtl">

# رموز المصحف العثماني

تطبيق ويب تفاعلي لعرض واستكشاف الحروف والرموز المستخدمة في الرسم العثماني للقرآن الكريم. هذه الأداة مصممة للطلاب والباحثين وكل من يهتم بتفاصيل النص القرآني.

## ✨ الميزات

- **مجموعة شاملة من الرموز**: يعرض مجموعة كاملة من الحروف والعلامات والرموز من الرسم العثماني، بناءً على اللوحة المرجعية المتوفرة.
- **تلميحات تفاعلية**: مرر الفأرة فوق أي حرف لعرض اسمه ووصف تفصيلي باللغة العربية لقاعدة التجويد أو وظيفته.
- **خط أصيل**: يستخدم خط **Amiri** الجميل، المصمم خصيصًا للغة العربية الكلاسيكية والنص القرآني، مما يضمن عرضًا دقيقًا وأنيقًا.
- **تصميم أنيق ومتجاوب**: واجهة نظيفة وجمالية مستوحاة من الفن الإسلامي، متجاوبة بالكامل ويمكن الوصول إليها على أجهزة الكمبيوتر المكتبية والأجهزة اللوحية والهواتف المحمولة.
- **أداة تعليمية**: بمثابة مرجع سريع وأداة تعليمية لفهم المعاني المحددة لمختلف الرموز القرآنية.

## 💻 التقنيات المستخدمة

- **React**: مكتبة جافاسكريبت حديثة لبناء واجهات المستخدم.
- **TypeScript**: لإضافة الأنواع الثابتة، مما يحسن جودة الكود وقابليته للصيانة.
- **Tailwind CSS**: إطار عمل CSS يعتمد على الأدوات المساعدة لتطوير واجهات المستخدم المخصصة بسرعة.
- **Google Fonts**: لاستيراد خط Amiri المتخصص.

## 🚀 كيفية التشغيل محليًا

هذا المشروع هو تطبيق ويب ثابت ولا يتطلب عملية بناء معقدة. يمكنك تشغيله بسهولة باستخدام خادم ويب محلي.

1.  **نسخ المستودع:**
    ```bash
    git clone https://github.com/your-username/uthmani-script-characters.git
    cd uthmani-script-characters
    ```

2.  **تشغيل المشروع:**
    إذا كان لديك إضافة خادم محلي في محرر الأكواد الخاص بك (مثل Live Server لـ VS Code)، يمكنك ببساطة فتح ملف `index.html` باستخدامه.

    بدلاً من ذلك، يمكنك استخدام خادم بسيط من سطر الأوامر. إذا كان لديك Node.js مثبتًا، يمكنك استخدام `serve`:
    ```bash
    # تثبيت serve عالميًا إذا لم يكن لديك
    npm install -g serve

    # تشغيل الخادم في دليل المشروع
    serve .
    ```
    سيعمل التطبيق الآن على منفذ محلي (على سبيل المثال `http://localhost:3000`).

## 🙏 شكر وتقدير

- هذا المشروع مستوحى من خريطة الرموز الموجودة في [karachvi.com](https://karachvi.com/quran/charsUsedUthmani.html).
- الطباعة العربية الجميلة أصبحت ممكنة بفضل مشروع [خط أميري (Amiri Font)](https://fonts.google.com/specimen/Amiri).

</div>
